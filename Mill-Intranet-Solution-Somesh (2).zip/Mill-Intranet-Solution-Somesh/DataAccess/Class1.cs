﻿using System;

namespace DataAccess
{
    public class Class1
    {
    }
}
