﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataAccess.DBEntities
{
    public class StudentEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Age { get; set; }
        public string Class { get; set; }
    }
}
