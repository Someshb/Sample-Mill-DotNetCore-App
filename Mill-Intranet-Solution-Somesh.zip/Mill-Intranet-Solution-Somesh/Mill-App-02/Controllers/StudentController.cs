﻿using DataAccess;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mill_App_02.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudent _studentRepository;
        private readonly IConfiguration _config;
        public StudentController(IConfiguration config,IStudent studentRepository)
        {
            _studentRepository = studentRepository;
            _config = config;
        }

        public IActionResult Index()
        {
            var result = _studentRepository.GetAllStudent();
            return View("Index",result);
        }
    }
}
